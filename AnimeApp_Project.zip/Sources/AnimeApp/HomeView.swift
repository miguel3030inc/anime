import SwiftUI

struct HomeView: View {
    let dataService = AnimeDataService.shared
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    // Featured section
                    FeaturedSection(animes: dataService.featuredAnime)
                    
                    // Popular section
                    SectionHeader(title: "Popular Anime")
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 15) {
                            ForEach(dataService.allAnime) { anime in
                                NavigationLink(destination: AnimeDetailView(anime: anime)) {
                                    AnimeCard(anime: anime)
                                }
                            }
                        }
                        .padding(.horizontal)
                    }
                    
                    // Recently added section
                    SectionHeader(title: "Recently Added")
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 15) {
                            ForEach(dataService.allAnime.shuffled()) { anime in
                                NavigationLink(destination: AnimeDetailView(anime: anime)) {
                                    AnimeCard(anime: anime)
                                }
                            }
                        }
                        .padding(.horizontal)
                    }
                }
                .padding(.vertical)
            }
            .navigationTitle("Anime Stream")
        }
    }
}

struct FeaturedSection: View {
    let animes: [AnimeSeries]
    
    var body: some View {
        TabView {
            ForEach(animes) { anime in
                NavigationLink(destination: AnimeDetailView(anime: anime)) {
                    ZStack(alignment: .bottom) {
                        // Image placeholder
                        Rectangle()
                            .fill(Color.gray.opacity(0.3))
                            .aspectRatio(16/9, contentMode: .fill)
                            .cornerRadius(10)
                        
                        // Title overlay
                        VStack(alignment: .leading) {
                            Text(anime.title)
                                .font(.title2)
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                            
                            Text(anime.genres.joined(separator: " • "))
                                .font(.subheadline)
                                .foregroundColor(.white.opacity(0.8))
                        }
                        .padding()
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(
                            LinearGradient(
                                gradient: Gradient(colors: [.clear, .black.opacity(0.8)]),
                                startPoint: .top,
                                endPoint: .bottom
                            )
                        )
                        .cornerRadius(10)
                    }
                    .frame(height: 200)
                }
            }
        }
        .tabViewStyle(PageTabViewStyle())
        .frame(height: 200)
        .padding(.horizontal)
    }
}

struct AnimeCard: View {
    let anime: AnimeSeries
    
    var body: some View {
        VStack(alignment: .leading) {
            // Image placeholder
            Rectangle()
                .fill(Color.gray.opacity(0.3))
                .aspectRatio(2/3, contentMode: .fit)
                .cornerRadius(8)
                .frame(width: 120)
            
            Text(anime.title)
                .font(.caption)
                .fontWeight(.medium)
                .lineLimit(1)
                .frame(width: 120, alignment: .leading)
            
            Text("\(anime.seasons.count) Season\(anime.seasons.count > 1 ? "s" : "")")
                .font(.caption2)
                .foregroundColor(.secondary)
        }
    }
}

struct SectionHeader: View {
    let title: String
    
    var body: some View {
        HStack {
            Text(title)
                .font(.title3)
                .fontWeight(.bold)
            
            Spacer()
            
            Button(action: {}) {
                Text("See All")
                    .font(.subheadline)
                    .foregroundColor(.purple)
            }
        }
        .padding(.horizontal)
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}