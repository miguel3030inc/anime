import SwiftUI

struct LibraryView: View {
    @State private var selectedTab = 0
    
    var body: some View {
        NavigationView {
            VStack {
                // Tab selector
                Picker("Library", selection: $selectedTab) {
                    Text("Watchlist").tag(0)
                    Text("History").tag(1)
                    Text("Downloads").tag(2)
                }
                .pickerStyle(SegmentedPickerStyle())
                .padding(.horizontal)
                
                if selectedTab == 0 {
                    WatchlistView()
                } else if selectedTab == 1 {
                    HistoryView()
                } else {
                    DownloadsView()
                }
            }
            .navigationTitle("My Library")
        }
    }
}

struct WatchlistView: View {
    // In a real app, this would be fetched from user data
    let watchlist: [AnimeSeries] = AnimeDataService.shared.allAnime.prefix(2).map { $0 }
    
    var body: some View {
        if watchlist.isEmpty {
            EmptyStateView(
                icon: "heart",
                title: "Your watchlist is empty",
                message: "Add anime series to your watchlist to keep track of what you want to watch"
            )
        } else {
            List {
                ForEach(watchlist) { anime in
                    NavigationLink(destination: AnimeDetailView(anime: anime)) {
                        HStack {
                            // Thumbnail
                            Rectangle()
                                .fill(Color.gray.opacity(0.3))
                                .frame(width: 80, height: 120)
                                .cornerRadius(8)
                            
                            VStack(alignment: .leading, spacing: 4) {
                                Text(anime.title)
                                    .font(.headline)
                                
                                Text(anime.genres.joined(separator: " • "))
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                                
                                Text("\(anime.seasons.count) Season\(anime.seasons.count > 1 ? "s" : "")")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                        }
                        .padding(.vertical, 4)
                    }
                }
            }
            .listStyle(PlainListStyle())
        }
    }
}

struct HistoryView: View {
    // In a real app, this would be fetched from user data
    let history: [AnimeSeries.Episode] = [
        AnimeDataService.shared.allAnime[0].seasons[0].episodes[0],
        AnimeDataService.shared.allAnime[1].seasons[0].episodes[0]
    ]
    
    var body: some View {
        if history.isEmpty {
            EmptyStateView(
                icon: "clock",
                title: "No watch history",
                message: "Your recently watched episodes will appear here"
            )
        } else {
            List {
                ForEach(history) { episode in
                    NavigationLink(destination: EpisodePlayerView(episode: episode, anime: AnimeDataService.shared.allAnime[0])) {
                        HStack {
                            // Thumbnail
                            Rectangle()
                                .fill(Color.gray.opacity(0.3))
                                .frame(width: 120, height: 68)
                                .cornerRadius(8)
                            
                            VStack(alignment: .leading, spacing: 4) {
                                Text("Episode \(episode.number): \(episode.title)")
                                    .font(.headline)
                                
                                Text("Watched 2 days ago")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                        }
                        .padding(.vertical, 4)
                    }
                }
            }
            .listStyle(PlainListStyle())
        }
    }
}

struct DownloadsView: View {
    var body: some View {
        EmptyStateView(
            icon: "arrow.down.circle",
            title: "No downloads",
            message: "Downloaded episodes will appear here for offline viewing"
        )
    }
}

struct EmptyStateView: View {
    let icon: String
    let title: String
    let message: String
    
    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: icon)
                .font(.system(size: 64))
                .foregroundColor(.purple)
            
            Text(title)
                .font(.title2)
                .fontWeight(.bold)
            
            Text(message)
                .font(.body)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 32)
            
            Spacer()
        }
        .padding(.top, 60)
    }
}

struct LibraryView_Previews: PreviewProvider {
    static var previews: some View {
        LibraryView()
    }
}