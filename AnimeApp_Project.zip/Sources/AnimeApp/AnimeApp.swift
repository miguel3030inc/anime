import SwiftUI

@main
struct AnimeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}