import SwiftUI

struct SearchView: View {
    @State private var searchText = ""
    let dataService = AnimeDataService.shared
    
    var filteredAnime: [AnimeSeries] {
        if searchText.isEmpty {
            return []
        } else {
            return dataService.allAnime.filter { anime in
                anime.title.lowercased().contains(searchText.lowercased()) ||
                anime.genres.joined(separator: " ").lowercased().contains(searchText.lowercased())
            }
        }
    }
    
    var body: some View {
        NavigationView {
            VStack {
                // Search bar
                HStack {
                    Image(systemName: "magnifyingglass")
                        .foregroundColor(.secondary)
                    
                    TextField("Search anime or genres", text: $searchText)
                        .autocapitalization(.none)
                    
                    if !searchText.isEmpty {
                        Button(action: {
                            searchText = ""
                        }) {
                            Image(systemName: "xmark.circle.fill")
                                .foregroundColor(.secondary)
                        }
                    }
                }
                .padding(10)
                .background(Color(.systemGray6))
                .cornerRadius(10)
                .padding(.horizontal)
                
                if searchText.isEmpty {
                    // Popular searches
                    VStack(alignment: .leading, spacing: 16) {
                        Text("Popular Searches")
                            .font(.headline)
                            .padding(.horizontal)
                        
                        ForEach(["Action", "Romance", "Fantasy", "Sci-Fi", "Comedy"], id: \.self) { genre in
                            Button(action: {
                                searchText = genre
                            }) {
                                Text(genre)
                                    .foregroundColor(.primary)
                            }
                            .padding(.horizontal)
                            
                            Divider()
                                .padding(.leading)
                        }
                    }
                    .padding(.top)
                    
                    Spacer()
                } else if filteredAnime.isEmpty {
                    // No results
                    VStack(spacing: 16) {
                        Image(systemName: "magnifyingglass")
                            .font(.system(size: 64))
                            .foregroundColor(.secondary)
                        
                        Text("No results found")
                            .font(.headline)
                        
                        Text("Try searching for a different anime or genre")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal)
                    }
                    .padding(.top, 60)
                    
                    Spacer()
                } else {
                    // Search results
                    List {
                        ForEach(filteredAnime) { anime in
                            NavigationLink(destination: AnimeDetailView(anime: anime)) {
                                HStack {
                                    // Thumbnail
                                    Rectangle()
                                        .fill(Color.gray.opacity(0.3))
                                        .frame(width: 80, height: 120)
                                        .cornerRadius(8)
                                    
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(anime.title)
                                            .font(.headline)
                                        
                                        Text(anime.genres.joined(separator: " • "))
                                            .font(.caption)
                                            .foregroundColor(.secondary)
                                        
                                        HStack {
                                            Image(systemName: "star.fill")
                                                .foregroundColor(.yellow)
                                                .font(.caption)
                                            
                                            Text(String(format: "%.1f", anime.rating))
                                                .font(.caption)
                                        }
                                    }
                                }
                                .padding(.vertical, 4)
                            }
                        }
                    }
                    .listStyle(PlainListStyle())
                }
            }
            .navigationTitle("Search")
        }
    }
}

struct SearchView_Previews: PreviewProvider {
    static var previews: some View {
        SearchView()
    }
}