import Foundation

struct AnimeSeries: Identifiable {
    let id: String
    let title: String
    let description: String
    let imageURL: String
    let seasons: [Season]
    let genres: [String]
    let rating: Double
    
    struct Season: Identifiable {
        let id: String
        let number: Int
        let episodes: [Episode]
    }
    
    struct Episode: Identifiable {
        let id: String
        let number: Int
        let title: String
        let description: String
        let thumbnailURL: String
        let videoURL: String
        let duration: TimeInterval
    }
}

// Mock data for testing
class AnimeDataService {
    static let shared = AnimeDataService()
    
    var featuredAnime: [AnimeSeries] {
        return allAnime.prefix(5).map { $0 }
    }
    
    var allAnime: [AnimeSeries] = [
        AnimeSeries(
            id: "1",
            title: "Attack on Titan",
            description: "In a world where humanity lives inside cities surrounded by enormous walls due to the Titans, gigantic humanoid creatures who devour humans seemingly without reason.",
            imageURL: "https://example.com/aot.jpg",
            seasons: [
                AnimeSeries.Season(
                    id: "s1",
                    number: 1,
                    episodes: [
                        AnimeSeries.Episode(
                            id: "e1",
                            number: 1,
                            title: "To You, 2000 Years From Now",
                            description: "After 100 years of peace, humanity is suddenly reminded of the terror of being at the Titans' mercy.",
                            thumbnailURL: "https://example.com/aot_s1e1.jpg",
                            videoURL: "https://example.com/videos/aot_s1e1.mp4",
                            duration: 24 * 60
                        ),
                        AnimeSeries.Episode(
                            id: "e2",
                            number: 2,
                            title: "That Day",
                            description: "After the Titan breaches Wall Maria, Eren vows to kill all Titans.",
                            thumbnailURL: "https://example.com/aot_s1e2.jpg",
                            videoURL: "https://example.com/videos/aot_s1e2.mp4",
                            duration: 24 * 60
                        )
                    ]
                ),
                AnimeSeries.Season(
                    id: "s2",
                    number: 2,
                    episodes: [
                        AnimeSeries.Episode(
                            id: "e1",
                            number: 1,
                            title: "Beast Titan",
                            description: "The Scout Regiment investigates a mysterious Titan.",
                            thumbnailURL: "https://example.com/aot_s2e1.jpg",
                            videoURL: "https://example.com/videos/aot_s2e1.mp4",
                            duration: 24 * 60
                        )
                    ]
                )
            ],
            genres: ["Action", "Drama", "Fantasy"],
            rating: 9.0
        ),
        AnimeSeries(
            id: "2",
            title: "Demon Slayer",
            description: "A young man's family is slaughtered by demons and his sister is transformed into one. He vows to become a demon slayer to avenge his family and cure his sister.",
            imageURL: "https://example.com/demonslayer.jpg",
            seasons: [
                AnimeSeries.Season(
                    id: "s1",
                    number: 1,
                    episodes: [
                        AnimeSeries.Episode(
                            id: "e1",
                            number: 1,
                            title: "Cruelty",
                            description: "Tanjiro's life changes when his family is slaughtered and his sister Nezuko is turned into a demon.",
                            thumbnailURL: "https://example.com/ds_s1e1.jpg",
                            videoURL: "https://example.com/videos/ds_s1e1.mp4",
                            duration: 24 * 60
                        )
                    ]
                )
            ],
            genres: ["Action", "Supernatural", "Historical"],
            rating: 8.7
        ),
        AnimeSeries(
            id: "3",
            title: "My Hero Academia",
            description: "In a world where people with superpowers known as 'Quirks' are the norm, Izuku Midoriya has dreams of becoming a hero despite being Quirkless.",
            imageURL: "https://example.com/mha.jpg",
            seasons: [
                AnimeSeries.Season(
                    id: "s1",
                    number: 1,
                    episodes: [
                        AnimeSeries.Episode(
                            id: "e1",
                            number: 1,
                            title: "Izuku Midoriya: Origin",
                            description: "Izuku Midoriya desperately wants to be a hero, but he is one of the few in his generation born without a Quirk.",
                            thumbnailURL: "https://example.com/mha_s1e1.jpg",
                            videoURL: "https://example.com/videos/mha_s1e1.mp4",
                            duration: 24 * 60
                        )
                    ]
                )
            ],
            genres: ["Action", "Comedy", "School"],
            rating: 8.5
        )
    ]
}