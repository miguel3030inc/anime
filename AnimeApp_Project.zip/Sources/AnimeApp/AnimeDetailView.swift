import SwiftUI

struct AnimeDetailView: View {
    let anime: AnimeSeries
    @State private var selectedSeason: AnimeSeries.Season
    
    init(anime: AnimeSeries) {
        self.anime = anime
        // Initialize with the first season
        _selectedSeason = State(initialValue: anime.seasons.first ?? AnimeSeries.Season(id: "", number: 0, episodes: []))
    }
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                // Header image
                Rectangle()
                    .fill(Color.gray.opacity(0.3))
                    .aspectRatio(16/9, contentMode: .fit)
                
                VStack(alignment: .leading, spacing: 12) {
                    // Title and rating
                    HStack {
                        Text(anime.title)
                            .font(.title)
                            .fontWeight(.bold)
                        
                        Spacer()
                        
                        HStack(spacing: 4) {
                            Image(systemName: "star.fill")
                                .foregroundColor(.yellow)
                            Text(String(format: "%.1f", anime.rating))
                                .fontWeight(.semibold)
                        }
                    }
                    
                    // Genres
                    HStack {
                        ForEach(anime.genres, id: \.self) { genre in
                            Text(genre)
                                .font(.caption)
                                .padding(.horizontal, 8)
                                .padding(.vertical, 4)
                                .background(Color.purple.opacity(0.2))
                                .cornerRadius(4)
                        }
                    }
                    
                    // Description
                    Text(anime.description)
                        .font(.body)
                        .foregroundColor(.secondary)
                        .padding(.vertical, 8)
                    
                    // Season selector
                    Picker("Season", selection: $selectedSeason) {
                        ForEach(anime.seasons) { season in
                            Text("Season \(season.number)").tag(season)
                        }
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    .padding(.vertical, 8)
                    
                    // Episodes list
                    Text("Episodes")
                        .font(.title3)
                        .fontWeight(.bold)
                        .padding(.top, 8)
                    
                    ForEach(selectedSeason.episodes) { episode in
                        NavigationLink(destination: EpisodePlayerView(episode: episode, anime: anime)) {
                            EpisodeRow(episode: episode)
                        }
                    }
                }
                .padding()
            }
        }
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct EpisodeRow: View {
    let episode: AnimeSeries.Episode
    
    var body: some View {
        HStack(spacing: 12) {
            // Thumbnail
            Rectangle()
                .fill(Color.gray.opacity(0.3))
                .aspectRatio(16/9, contentMode: .fill)
                .frame(width: 120, height: 68)
                .cornerRadius(8)
            
            VStack(alignment: .leading, spacing: 4) {
                Text("Episode \(episode.number): \(episode.title)")
                    .font(.headline)
                    .lineLimit(1)
                
                Text(episode.description)
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .lineLimit(2)
                
                Text(formatDuration(episode.duration))
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            Image(systemName: "play.circle")
                .font(.title2)
                .foregroundColor(.purple)
        }
        .padding(.vertical, 8)
    }
    
    private func formatDuration(_ seconds: TimeInterval) -> String {
        let minutes = Int(seconds / 60)
        return "\(minutes) min"
    }
}