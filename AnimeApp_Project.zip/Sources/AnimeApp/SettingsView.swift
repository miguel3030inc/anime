import SwiftUI

struct SettingsView: View {
    @State private var isDarkMode = false
    @State private var autoplay = true
    @State private var streamingQuality = "Auto"
    @State private var downloadQuality = "High"
    @State private var notificationsEnabled = true
    
    let qualityOptions = ["Auto", "Low", "Medium", "High"]
    
    var body: some View {
        NavigationView {
            List {
                Section(header: Text("Appearance")) {
                    Toggle("Dark Mode", isOn: $isDarkMode)
                }
                
                Section(header: Text("Playback")) {
                    Toggle("Autoplay Next Episode", isOn: $autoplay)
                    
                    Picker("Streaming Quality", selection: $streamingQuality) {
                        ForEach(qualityOptions, id: \.self) { option in
                            Text(option)
                        }
                    }
                    
                    Picker("Download Quality", selection: $downloadQuality) {
                        ForEach(qualityOptions, id: \.self) { option in
                            Text(option)
                        }
                    }
                }
                
                Section(header: Text("Notifications")) {
                    Toggle("Enable Notifications", isOn: $notificationsEnabled)
                    
                    if notificationsEnabled {
                        NavigationLink(destination: NotificationSettingsView()) {
                            Text("Notification Preferences")
                        }
                    }
                }
                
                Section(header: Text("Account")) {
                    NavigationLink(destination: AccountView()) {
                        Text("Account Information")
                    }
                    
                    NavigationLink(destination: SubscriptionView()) {
                        Text("Subscription")
                    }
                }
                
                Section(header: Text("About")) {
                    HStack {
                        Text("Version")
                        Spacer()
                        Text("1.0.0")
                            .foregroundColor(.secondary)
                    }
                    
                    NavigationLink(destination: PrivacyPolicyView()) {
                        Text("Privacy Policy")
                    }
                    
                    NavigationLink(destination: TermsOfServiceView()) {
                        Text("Terms of Service")
                    }
                    
                    Button(action: {}) {
                        Text("Contact Support")
                            .foregroundColor(.primary)
                    }
                }
            }
            .listStyle(InsetGroupedListStyle())
            .navigationTitle("Settings")
        }
    }
}

struct NotificationSettingsView: View {
    @State private var newEpisodes = true
    @State private var newSeries = true
    @State private var recommendations = true
    
    var body: some View {
        List {
            Toggle("New Episodes", isOn: $newEpisodes)
            Toggle("New Series", isOn: $newSeries)
            Toggle("Recommendations", isOn: $recommendations)
        }
        .navigationTitle("Notification Preferences")
    }
}

struct AccountView: View {
    var body: some View {
        List {
            HStack {
                Text("Email")
                Spacer()
                Text("user@example.com")
                    .foregroundColor(.secondary)
            }
            
            Button(action: {}) {
                Text("Change Password")
                    .foregroundColor(.primary)
            }
            
            Button(action: {}) {
                Text("Sign Out")
                    .foregroundColor(.red)
            }
        }
        .navigationTitle("Account")
    }
}

struct SubscriptionView: View {
    var body: some View {
        VStack(spacing: 20) {
            Text("Premium Subscription")
                .font(.title2)
                .fontWeight(.bold)
            
            Text("Active")
                .font(.headline)
                .foregroundColor(.green)
                .padding(.horizontal, 16)
                .padding(.vertical, 8)
                .background(Color.green.opacity(0.2))
                .cornerRadius(8)
            
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    Text("Plan")
                    Spacer()
                    Text("Premium Monthly")
                        .foregroundColor(.secondary)
                }
                
                HStack {
                    Text("Renewal Date")
                    Spacer()
                    Text("June 15, 2023")
                        .foregroundColor(.secondary)
                }
                
                HStack {
                    Text("Price")
                    Spacer()
                    Text("$9.99/month")
                        .foregroundColor(.secondary)
                }
            }
            .padding()
            .background(Color(.systemGray6))
            .cornerRadius(12)
            .padding(.horizontal)
            
            Button(action: {}) {
                Text("Manage Subscription")
                    .fontWeight(.semibold)
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.purple)
                    .cornerRadius(12)
                    .padding(.horizontal)
            }
            
            Spacer()
        }
        .padding(.top, 20)
        .navigationTitle("Subscription")
    }
}

struct PrivacyPolicyView: View {
    var body: some View {
        ScrollView {
            Text("Privacy Policy content would go here...")
                .padding()
        }
        .navigationTitle("Privacy Policy")
    }
}

struct TermsOfServiceView: View {
    var body: some View {
        ScrollView {
            Text("Terms of Service content would go here...")
                .padding()
        }
        .navigationTitle("Terms of Service")
    }
}

struct SettingsView_Previews: PreviewProvider {
    static var previews: some View {
        SettingsView()
    }
}