import SwiftUI
import AVKit

struct EpisodePlayerView: View {
    let episode: AnimeSeries.Episode
    let anime: AnimeSeries
    @State private var player = AVPlayer()
    @State private var isPlaying = false
    
    var body: some View {
        VStack(spacing: 0) {
            // Video player
            VideoPlayer(player: player)
                .aspectRatio(16/9, contentMode: .fit)
                .onAppear {
                    // In a real app, we would use the actual URL
                    // For demo purposes, we're using a placeholder
                    if let url = URL(string: episode.videoURL) {
                        let playerItem = AVPlayerItem(url: url)
                        player.replaceCurrentItem(with: playerItem)
                        player.play()
                        isPlaying = true
                    }
                }
                .onDisappear {
                    player.pause()
                }
            
            // Episode info
            VStack(alignment: .leading, spacing: 12) {
                Text("\(anime.title) - Season \(getCurrentSeason().number)")
                    .font(.headline)
                    .foregroundColor(.secondary)
                
                Text("Episode \(episode.number): \(episode.title)")
                    .font(.title2)
                    .fontWeight(.bold)
                
                Text(episode.description)
                    .font(.body)
                    .foregroundColor(.secondary)
                    .padding(.top, 4)
                
                // Custom player controls
                HStack(spacing: 24) {
                    Button(action: rewind) {
                        Image(systemName: "gobackward.10")
                            .font(.title2)
                    }
                    
                    Button(action: togglePlayPause) {
                        Image(systemName: isPlaying ? "pause.circle.fill" : "play.circle.fill")
                            .font(.title)
                    }
                    
                    Button(action: fastForward) {
                        Image(systemName: "goforward.10")
                            .font(.title2)
                    }
                    
                    Spacer()
                    
                    Button(action: {}) {
                        Image(systemName: "square.and.arrow.up")
                            .font(.title2)
                    }
                }
                .padding(.top, 16)
                .foregroundColor(.purple)
                
                // Next episode button
                if hasNextEpisode() {
                    Button(action: playNextEpisode) {
                        HStack {
                            Text("Next Episode")
                                .fontWeight(.semibold)
                            
                            Spacer()
                            
                            Image(systemName: "chevron.right")
                        }
                        .padding()
                        .background(Color.purple.opacity(0.1))
                        .cornerRadius(8)
                    }
                    .padding(.top, 16)
                }
            }
            .padding()
            
            Spacer()
        }
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button(action: {}) {
                    Image(systemName: "heart")
                }
            }
        }
    }
    
    private func getCurrentSeason() -> AnimeSeries.Season {
        return anime.seasons.first(where: { season in
            season.episodes.contains(where: { $0.id == episode.id })
        }) ?? anime.seasons.first!
    }
    
    private func hasNextEpisode() -> Bool {
        let season = getCurrentSeason()
        return season.episodes.last?.id != episode.id || anime.seasons.last?.id != season.id
    }
    
    private func playNextEpisode() {
        let season = getCurrentSeason()
        if let currentIndex = season.episodes.firstIndex(where: { $0.id == episode.id }) {
            if currentIndex < season.episodes.count - 1 {
                // Play next episode in current season
                // In a real app, we would navigate to the next episode
            } else if let currentSeasonIndex = anime.seasons.firstIndex(where: { $0.id == season.id }),
                      currentSeasonIndex < anime.seasons.count - 1 {
                // Play first episode of next season
                // In a real app, we would navigate to the next season's first episode
            }
        }
    }
    
    private func togglePlayPause() {
        isPlaying.toggle()
        if isPlaying {
            player.play()
        } else {
            player.pause()
        }
    }
    
    private func rewind() {
        let currentTime = player.currentTime().seconds
        player.seek(to: CMTime(seconds: max(0, currentTime - 10), preferredTimescale: 1))
    }
    
    private func fastForward() {
        let currentTime = player.currentTime().seconds
        player.seek(to: CMTime(seconds: currentTime + 10, preferredTimescale: 1))
    }
}